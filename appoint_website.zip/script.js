function bookAppointment() {
    alert("Appointment booked successfully!");
}
